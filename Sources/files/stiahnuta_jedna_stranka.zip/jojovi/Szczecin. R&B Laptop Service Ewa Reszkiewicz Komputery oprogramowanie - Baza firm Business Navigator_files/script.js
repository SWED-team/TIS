// (c) 2000-2007 by Gemius SA
function gxyadem_emission() {

}
var gxyadem_gemius_host = 'http://st.hit.gemius.pl/_'+(new Date()).getTime();
var gxyadem_gemius_args = 'id=SGO2Ykvw87s1n689kpBHV68JwRM4Z9F4IZwwIYX7nEj.l7&from=s1.hit.stat24.com&';
var gxy_url_params = 'id=ctfqlk86o0qhuWGA2CY5wvUH..ldBGPmfkmop7Lk2bX.P7/l=11';
var gxy_host = gxyadem_gemius_host+'/redot.gif?id=syM8uKgBHqGL4P6K2eld8rUkovDcUdxqDFdMkbj21FL.77&';
document.writeln('<'+'script type="text/javascript" src="http://s1.hit.stat24.com/cachedscriptxy.js"><'+'/script>');

